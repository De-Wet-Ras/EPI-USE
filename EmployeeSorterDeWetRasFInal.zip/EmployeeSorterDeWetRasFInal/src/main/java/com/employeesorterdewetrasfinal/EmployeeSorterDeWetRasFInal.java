/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.employeesorterdewetrasfinal;
/**
 *
 * @author De Wet Ras
 *
 */
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.*;
import java.util.*;

public class EmployeeSorterDeWetRasFInal {

    private static String EMPLOYEE_URL;
    private static String RELATIONSHIP_URL;
    private static String SUBMIT_URL;
    private static String TOKEN;
    private static int BATCH_SIZE;

    public static void main(String[] args) {
        try {
            // Load properties from config file
            loadConfig();

            // Setup the database if needed
            try (Connection connection = DriverManager.getConnection("jdbc:sqlite:employee_relationships.db")) {
                setupDatabase(connection);

                // Fetch employees and relationships from the API
                Map<String, String> employees = fetchAllData(EMPLOYEE_URL, "id", "name");
                System.out.println("Total Employees Fetched: " + employees.size());

                List<Map<String, String>> relationships = fetchAllRelationships();
                System.out.println("Total Relationships Fetched: " + relationships.size());

                // Insert data into SQLite database
                insertData(connection, employees, relationships);

                // Populate the hierarchy table
                populateHierarchyTable(connection, employees, relationships);

                // Fetch data from the hierarchy table for submission
                List<Map<String, String>> hierarchyData = fetchHierarchyData(connection);
                System.out.println("Total Hierarchy Data for Submission: " + hierarchyData.size());

                // Submit the hierarchy data
                submitData(hierarchyData);

                System.out.println("Data has been submitted successfully.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void loadConfig() throws IOException {
        // Load the properties file
        Properties properties = new Properties();
        try (InputStream input = new FileInputStream("config.properties")) {
            properties.load(input);

            // Set the values from properties file
            EMPLOYEE_URL = properties.getProperty("employee_url");
            RELATIONSHIP_URL = properties.getProperty("relationship_url");
            SUBMIT_URL = properties.getProperty("submit_url");
            TOKEN = properties.getProperty("candidate_token");
            BATCH_SIZE = Integer.parseInt(properties.getProperty("batch_size"));
        }
    }

    private static void setupDatabase(Connection connection) throws SQLException {
        // Create tables for employees, relationships, and hierarchy
        String createEmployeesTable = """
                CREATE TABLE IF NOT EXISTS employees (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL
                );
                """;

        String createRelationshipsTable = """
                CREATE TABLE IF NOT EXISTS relationships (
                    managerId TEXT NOT NULL,
                    reporteeId TEXT NOT NULL,
                    FOREIGN KEY(managerId) REFERENCES employees(id),
                    FOREIGN KEY(reporteeId) REFERENCES employees(id)
                );
                """;

        String createHierarchyTable = """
                CREATE TABLE IF NOT EXISTS hierarchy (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    managerId TEXT,
                    FOREIGN KEY(managerId) REFERENCES employees(id)
                );
                """;

        try (Statement stmt = connection.createStatement()) {
            stmt.execute(createEmployeesTable);
            stmt.execute(createRelationshipsTable);
            stmt.execute(createHierarchyTable);
        }
    }

    private static Map<String, String> fetchAllData(String url, String keyId, String keyName) throws IOException, InterruptedException {
        Map<String, String> data = new HashMap<>();
        int skip = 0;

        while (true) {
            Map<String, String> batch = fetchBatch(url, skip, BATCH_SIZE, keyId, keyName);
            if (batch.isEmpty()) break;

            data.putAll(batch);
            skip += BATCH_SIZE;
        }
        return data;
    }

    private static Map<String, String> fetchBatch(String url, int skip, int limit, String keyId, String keyName) throws IOException, InterruptedException {
        String apiUrl = url + "?limit=" + limit + "&skip=" + skip;
        URI uri = URI.create(apiUrl);

        HttpRequest request = HttpRequest.newBuilder(uri)
                .header("candidate-token", TOKEN)
                .build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200) {
            return parseBatchData(response.body(), keyId, keyName);
        }
        return Collections.emptyMap();
    }

    private static Map<String, String> parseBatchData(String json, String keyId, String keyName) throws IOException {
        Map<String, String> results = new HashMap<>();
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode data = objectMapper.readTree(json).path("data");

        if (data.isArray()) {
            for (JsonNode node : data) {
                Map<String, String> item = new HashMap<>();
                item.put("id", node.path(keyId).asText());
                item.put("name", node.path(keyName).asText());
                results.put(item.get("id"), item.get("name"));
            }
        }
        return results;
    }

    private static List<Map<String, String>> fetchAllRelationships() throws IOException, InterruptedException {
        List<Map<String, String>> relationships = new ArrayList<>();
        int skip = 0;

        while (true) {
            List<Map<String, String>> batch = fetchRelationshipBatch(skip, BATCH_SIZE);
            if (batch.isEmpty()) break;

            relationships.addAll(batch);
            skip += BATCH_SIZE;
        }
        return relationships;
    }

    private static List<Map<String, String>> fetchRelationshipBatch(int skip, int limit) throws IOException, InterruptedException {
        String apiUrl = RELATIONSHIP_URL + "?limit=" + limit + "&skip=" + skip;
        URI uri = URI.create(apiUrl);

        HttpRequest request = HttpRequest.newBuilder(uri)
                .header("candidate-token", TOKEN)
                .build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200) {
            return parseRelationshipBatchData(response.body());
        }
        return Collections.emptyList();
    }

    private static List<Map<String, String>> parseRelationshipBatchData(String json) throws IOException {
        List<Map<String, String>> results = new ArrayList<>();
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode data = objectMapper.readTree(json).path("data");

        if (data.isArray()) {
            for (JsonNode node : data) {
                Map<String, String> relationship = new HashMap<>();
                relationship.put("managerId", node.path("managerId").asText());
                relationship.put("reporteeId", node.path("reporteeId").asText());
                results.add(relationship);
            }
        }
        return results;
    }

    private static void insertData(Connection connection, Map<String, String> employees, List<Map<String, String>> relationships) throws SQLException {
        String insertEmployee = "INSERT OR IGNORE INTO employees (id, name) VALUES (?, ?)";
        String insertRelationship = "INSERT OR IGNORE INTO relationships (managerId, reporteeId) VALUES (?, ?)";

        try (PreparedStatement employeeStmt = connection.prepareStatement(insertEmployee);
             PreparedStatement relationshipStmt = connection.prepareStatement(insertRelationship)) {

            // Insert employees
            for (Map.Entry<String, String> employee : employees.entrySet()) {
                employeeStmt.setString(1, employee.getKey());
                employeeStmt.setString(2, employee.getValue());
                employeeStmt.addBatch();
            }
            employeeStmt.executeBatch();

            // Insert relationships
            for (Map<String, String> relationship : relationships) {
                relationshipStmt.setString(1, relationship.get("managerId"));
                relationshipStmt.setString(2, relationship.get("reporteeId"));
                relationshipStmt.addBatch();
            }
            relationshipStmt.executeBatch();
        }
    }

    private static void populateHierarchyTable(Connection connection, Map<String, String> employees, List<Map<String, String>> relationships) throws SQLException {
        String insertHierarchy = "INSERT OR REPLACE INTO hierarchy (id, name, managerId) VALUES (?, ?, ?)";

        try (PreparedStatement hierarchyStmt = connection.prepareStatement(insertHierarchy)) {

            // Step 1: Insert Gertrudis explicitly as the first entry with NULL manager
            String gertrudisId = "zeh04ompuhrcxy8bfttmy6tm";
            String gertrudisName = "Gertrudis";
            String gertrudisManager = "zeh04ompuhrcxy8bfttmy6tm";

            // Only insert if Gertrudis doesn't already exist in the table
            hierarchyStmt.setString(1, gertrudisId);
            hierarchyStmt.setString(2, gertrudisName);
            hierarchyStmt.setString(3, gertrudisManager); // No manager for Gertrudis
            hierarchyStmt.addBatch();

            // Step 2: Insert all other employees
            for (Map.Entry<String, String> employee : employees.entrySet()) {
                String employeeId = employee.getKey();
                String employeeName = employee.getValue();
                hierarchyStmt.setString(1, employeeId);
                hierarchyStmt.setString(2, employeeName);
                hierarchyStmt.setString(3, null); // No manager if they have no reportees
                hierarchyStmt.addBatch();
            }

            // Step 3: Insert relationships (employee-manager pairs)
            for (Map<String, String> relationship : relationships) {
                String managerId = relationship.get("managerId");
                String reporteeId = relationship.get("reporteeId");

                String managerName = employees.get(managerId);
                String reporteeName = employees.get(reporteeId);

                hierarchyStmt.setString(1, reporteeId);
                hierarchyStmt.setString(2, reporteeName);
                hierarchyStmt.setString(3, managerId);
                hierarchyStmt.addBatch();
            }

            // Step 4: Execute the batch
            hierarchyStmt.executeBatch();
        }
    }






    private static List<Map<String, String>> fetchHierarchyData(Connection connection) throws SQLException {
        String selectHierarchy = "SELECT id, name, managerId FROM hierarchy";
        List<Map<String, String>> hierarchyData = new ArrayList<>();

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(selectHierarchy)) {
            while (rs.next()) {
                Map<String, String> data = new HashMap<>();
                data.put("id", rs.getString("id"));
                data.put("name", rs.getString("name"));
                data.put("managerId", rs.getString("managerId"));
                hierarchyData.add(data);
            }
        }
        return hierarchyData;
    }

    private static void submitData(List<Map<String, String>> hierarchyData) throws IOException, InterruptedException {
        // Convert all hierarchy data into a single JSON payload
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonPayload = objectMapper.writeValueAsString(hierarchyData);

        // Submit the combined data in one batch
        submitBatchData(jsonPayload);
    }


    private static void submitBatchData(String json) throws IOException, InterruptedException {
        URI uri = URI.create(SUBMIT_URL);

        HttpRequest request = HttpRequest.newBuilder(uri)
                .header("candidate-token", TOKEN)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200) {
            System.out.println("All data submitted successfully!");
        } else {
            System.err.println("Error submitting data: " + response.statusCode());
            System.err.println("Response: " + response.body());
        }
    }



    private static List<List<Map<String, String>>> createBatches(List<Map<String, String>> hierarchyData, int batchSize) {
        List<List<Map<String, String>>> batches = new ArrayList<>();
        for (int i = 0; i < hierarchyData.size(); i += batchSize) {
            int end = Math.min(i + batchSize, hierarchyData.size());
            batches.add(hierarchyData.subList(i, end));
        }
        return batches;
    }
}
